# Code scope

The synthetic fixture and target-calibrated scores are supplied in `data/`. `verify_data.py` checks file structure. `run_reproduction.py` recomputes metrics from the supplied synthetic scores. The generator is not included. These scripts do not train or evaluate the manuscript model on empirical transactions.

## Contents

- `run_reproduction.py`: validates input structure and recomputes metrics from synthetic score tables.
- `verify_data.py`: performs schema, count, split, and query-structure checks.
- `requirements.txt`: Python dependencies.

## Run

Run from the root of the extracted archive:

```text
python code/run_reproduction.py --data-dir data --output-dir reproduction_outputs
```

The run writes `results_recomputed.csv`, `results_comparison.csv`, `table_1_network_summary.csv`, `table_2_ablation_recomputed.csv`, `conclusion_checks.csv`, `run_manifest.json`, and `reproduction_report.md`.

## Reproducibility boundary

The score tables are target-calibrated synthetic outputs. Recomputing their metrics verifies the calculations and internal consistency of this fixture only. It does not rerun or validate the empirical model-training pipeline.

