from __future__ import annotations

import argparse
import json
from pathlib import Path

from run_reproduction import locate_data_dir, validate_inputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_dir", type=Path, help="Extracted data directory or its parent")
    args = parser.parse_args()
    data_dir = locate_data_dir(args.data_dir)
    print(json.dumps({"data_dir": str(data_dir), "valid": True, "counts": validate_inputs(data_dir)}, indent=2))


if __name__ == "__main__":
    main()
