
from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


SCORE_METHODS = [
    "GCN",
    "HGAN",
    "Node2Vec",
    "Ours_full",
    "Without_expansion",
    "Without_finetuning",
    "Without_ontology",
]

EXPECTED_COLUMNS = {
    "companies.csv": {"company_id", "company_name", "stage", "city", "industry"},
    "products.csv": {"product_id", "product_name", "stage"},
    "process_rules.csv": {"source_product", "destination_product", "relation"},
    "positive_edges.csv": {"supplier_idx", "buyer_idx", "edge_id", "split"},
    "train_edges.csv": {"supplier_idx", "buyer_idx", "edge_id", "split"},
    "test_edges.csv": {"supplier_idx", "buyer_idx", "edge_id", "split"},
    "test_queries.csv": {"query_id", "candidate_rank", "supplier_idx", "buyer_idx", "label"},
}
SCORE_COLUMNS = {"query_id", "candidate_rank", "supplier_idx", "buyer_idx", "label", "score"}
EXPECTED_COUNTS = {
    "companies.csv": 206,
    "products.csv": 267,
    "process_rules.csv": 30,
    "positive_edges.csv": 5432,
    "train_edges.csv": 4345,
    "test_edges.csv": 1087,
    "test_queries.csv": 1087 * 51,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--data-dir", type=Path, help="Directory containing the synthetic CSV files")
    source.add_argument("--data-zip", type=Path, help="ZIP archive containing the synthetic CSV files")
    parser.add_argument("--output-dir", type=Path, default=Path("reproduction_outputs"))
    parser.add_argument("--tolerance", type=float, default=1e-10)
    return parser.parse_args()


def locate_data_dir(root: Path) -> Path:
    root = root.resolve()
    candidates = [
        root,
        root / "data",
    ]
    candidates.extend(path.parent for path in root.rglob("synthetic_results.csv"))
    for candidate in candidates:
        if (candidate / "companies.csv").exists() and (candidate / "synthetic_results.csv").exists():
            return candidate
    raise FileNotFoundError("Could not locate companies.csv and synthetic_results.csv under the supplied path")


def read_csv(data_dir: Path, name: str) -> pd.DataFrame:
    path = data_dir / name
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def validate_inputs(data_dir: Path) -> dict:
    frames = {name: read_csv(data_dir, name) for name in EXPECTED_COLUMNS}
    for name, frame in frames.items():
        missing = EXPECTED_COLUMNS[name] - set(frame.columns)
        if missing:
            raise ValueError(f"{name} is missing columns: {sorted(missing)}")
        expected = EXPECTED_COUNTS[name]
        if len(frame) != expected:
            raise ValueError(f"{name} has {len(frame)} rows; expected {expected}")

    companies = frames["companies.csv"]
    products = frames["products.csv"]
    rules = frames["process_rules.csv"]
    edges = frames["positive_edges.csv"]
    train = frames["train_edges.csv"]
    test = frames["test_edges.csv"]
    queries = frames["test_queries.csv"]

    if companies.company_id.nunique() != len(companies):
        raise ValueError("company_id values are not unique")
    if products.product_id.nunique() != len(products):
        raise ValueError("product_id values are not unique")
    if edges.duplicated(["supplier_idx", "buyer_idx"]).any():
        raise ValueError("positive_edges.csv contains duplicate directed edges")
    if set(train.edge_id) & set(test.edge_id):
        raise ValueError("train and test edge IDs overlap")
    if set(train.edge_id) | set(test.edge_id) != set(edges.edge_id):
        raise ValueError("train/test edge IDs do not partition positive_edges.csv")
    if set(edges.split) != {"train", "test"}:
        raise ValueError("positive_edges.csv must contain train and test split labels")
    if not (queries.label == 1).groupby(queries.query_id).sum().eq(1).all():
        raise ValueError("each test query must contain exactly one positive candidate")
    query_sizes = queries.groupby("query_id").size()
    if not query_sizes.eq(51).all():
        raise ValueError("each test query must contain one positive and 50 negative candidates")
    if queries.query_id.nunique() != len(test):
        raise ValueError("test query count must equal test edge count")

    return {
        "companies": len(companies),
        "products": len(products),
        "process_rules": len(rules),
        "positive_edges": len(edges),
        "train_edges": len(train),
        "test_edges": len(test),
        "test_queries": int(queries.query_id.nunique()),
        "candidates_per_query": int(query_sizes.iloc[0]),
        "split": "80/20 fixed train/test split supplied in positive_edges.csv",
    }


def rank_metrics(scores: pd.DataFrame) -> dict:
    y_true = scores["label"].to_numpy(dtype=int)
    y_score = scores["score"].to_numpy(dtype=float)
    ordered = scores.sort_values(
        ["query_id", "score", "candidate_rank"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    ranks = (
        ordered.assign(_positive=ordered["label"].eq(1))
        .groupby("query_id", sort=True)["_positive"]
        .apply(lambda values: int(np.flatnonzero(values.to_numpy())[0]) + 1)
    )
    return {
        "AUC": float(roc_auc_score(y_true, y_score)),
        "AP": float(average_precision_score(y_true, y_score)),
        "Hits@1": float((ranks <= 1).mean()),
        "Hits@5": float((ranks <= 5).mean()),
        "Hits@10": float((ranks <= 10).mean()),
        "MRR": float((1.0 / ranks).mean()),
    }


def recompute_results(data_dir: Path, tolerance: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    provided = read_csv(data_dir, "synthetic_results.csv")
    rows = []
    comparison = []
    for method in SCORE_METHODS:
        scores = read_csv(data_dir, f"scores_{method}.csv")
        missing = SCORE_COLUMNS - set(scores.columns)
        if missing:
            raise ValueError(f"scores_{method}.csv is missing columns: {sorted(missing)}")
        if len(scores) != 1087 * 51:
            raise ValueError(f"scores_{method}.csv has {len(scores)} rows; expected {1087 * 51}")
        metrics = rank_metrics(scores)
        rows.append({"method": method, **metrics})
        expected = provided.loc[provided.method.eq(method)]
        if len(expected) != 1:
            raise ValueError(f"synthetic_results.csv must contain exactly one row for {method}")
        expected_row = expected.iloc[0]
        for metric, value in metrics.items():
            difference = float(value - expected_row[metric])
            comparison.append({"method": method, "metric": metric, "provided": float(expected_row[metric]), "recomputed": value, "difference": difference, "within_tolerance": abs(difference) <= tolerance})
    return pd.DataFrame(rows), pd.DataFrame(comparison)


def write_outputs(data_dir: Path, output_dir: Path, tolerance: float) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    counts = validate_inputs(data_dir)
    results, comparison = recompute_results(data_dir, tolerance)
    if not comparison.within_tolerance.all():
        bad = comparison.loc[~comparison.within_tolerance]
        raise ValueError(f"Recomputed metrics differ from supplied results: {bad.to_dict('records')}")

    edges = read_csv(data_dir, "positive_edges.csv")
    stage_counts = read_csv(data_dir, "companies.csv")["stage"].value_counts().rename_axis("stage").reset_index(name="companies")
    summary = pd.DataFrame(
        [
            {"quantity": "companies", "value": len(read_csv(data_dir, "companies.csv"))},
            {"quantity": "products", "value": len(read_csv(data_dir, "products.csv"))},
            {"quantity": "process_rules", "value": len(read_csv(data_dir, "process_rules.csv"))},
            {"quantity": "positive_edges", "value": len(edges)},
            {"quantity": "training_edges", "value": int((edges.split == "train").sum())},
            {"quantity": "test_edges", "value": int((edges.split == "test").sum())},
        ]
    )
    conclusions = pd.DataFrame(
        [
            {"check": "Ours_full has the highest AUC", "result": bool(results.loc[results.method.eq("Ours_full"), "AUC"].iloc[0] == results.AUC.max())},
            {"check": "Ours_full has the highest AP", "result": bool(results.loc[results.method.eq("Ours_full"), "AP"].iloc[0] == results.AP.max())},
            {"check": "Ontology ablation lowers AUC", "result": bool(results.loc[results.method.eq("Ours_full"), "AUC"].iloc[0] > results.loc[results.method.eq("Without_ontology"), "AUC"].iloc[0])},
            {"check": "Fine-tuning ablation lowers AUC", "result": bool(results.loc[results.method.eq("Ours_full"), "AUC"].iloc[0] > results.loc[results.method.eq("Without_finetuning"), "AUC"].iloc[0])},
            {"check": "Expansion ablation lowers AUC", "result": bool(results.loc[results.method.eq("Ours_full"), "AUC"].iloc[0] > results.loc[results.method.eq("Without_expansion"), "AUC"].iloc[0])},
        ]
    )
    results.to_csv(output_dir / "results_recomputed.csv", index=False)
    comparison.to_csv(output_dir / "results_comparison.csv", index=False)
    summary.to_csv(output_dir / "table_1_network_summary.csv", index=False)
    stage_counts.to_csv(output_dir / "company_stage_counts.csv", index=False)
    results[results.method.isin(["Ours_full", "Without_ontology", "Without_finetuning", "Without_expansion"])].to_csv(output_dir / "table_2_ablation_recomputed.csv", index=False)
    conclusions.to_csv(output_dir / "conclusion_checks.csv", index=False)
    manifest = {"data_dir": str(data_dir), "input_files": {p.name: sha256(p) for p in sorted(data_dir.glob("*.csv"))}, "validated_counts": counts, "metrics_match_supplied_results": True, "tolerance": tolerance}
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    report = [
        "# Reproduction run",
        "",
        "The run validated the synthetic CSV schemas, counts, split integrity, and buyer-conditioned query structure.",
        "Metrics were recomputed from the target-calibrated synthetic score tables and matched synthetic_results.csv within the declared tolerance.",
        "",
        "## Network summary",
        "",
        summary.to_string(index=False),
        "",
        "## Recomputed results",
        "",
        results.to_string(index=False),
        "",
        "## Scope",
        "",
        "These checks validate only the synthetic demonstration. The scores were calibrated to target metrics and do not independently reproduce or validate empirical model performance.",
    ]
    (output_dir / "reproduction_report.md").write_text("\n".join(report), encoding="utf-8")
    return manifest


def main() -> None:
    args = parse_args()
    if args.data_zip:
        with tempfile.TemporaryDirectory(prefix="iise_data_") as temporary:
            with zipfile.ZipFile(args.data_zip) as archive:
                archive.extractall(temporary)
            data_dir = locate_data_dir(Path(temporary))
            manifest = write_outputs(data_dir, args.output_dir, args.tolerance)
    else:
        data_dir = locate_data_dir(args.data_dir)
        manifest = write_outputs(data_dir, args.output_dir, args.tolerance)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
